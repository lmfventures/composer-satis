<?php

namespace OcrTools\Services;

class OCRInvoiceParser
{
    public static function extract(string $ocr): array
    {
        $ocr = preg_replace('/\r\n|\r/', "\n", $ocr);

        preg_match('/INVOICE NO:\s*(\d+)/i', $ocr, $invoiceNoMatch);
        preg_match('/ISSUED TO:\s*(.*?)\n/i', $ocr, $issuedToMatch);
        preg_match('/DATE:\s*([\d.]+)/i', $ocr, $dateMatch);
        preg_match('/TOTAL[\s:]*\$?(\d+(?:\.\d+)?)/i', $ocr, $totalMatch);
        preg_match('/OR\s*(NO\.?|Number):?\s*(\d+)/i', $ocr, $orMatch);

        return [
            'invoice_number' => $invoiceNoMatch[1] ?? null,
            'issued_to'      => $issuedToMatch[1] ?? null,
            'invoice_date'   => $dateMatch[1] ?? null,
            'or_number'      => $orMatch[2] ?? null,
            'currency'       => config('ocr.default_currency', 'php'),
            'total'          => $totalMatch[1] ?? null,
        ];
    }
}
