<?php

namespace OcrTools\Services;

use Google\Cloud\Vision\V1\Client\ImageAnnotatorClient;
use Google\Cloud\Vision\V1\Image;
use Google\Cloud\Vision\V1\Feature;
use Google\Cloud\Vision\V1\AnnotateImageRequest;
use Google\Cloud\Vision\V1\BatchAnnotateImagesRequest;
use GuzzleHttp\Client;
use Exception;

class OCRImageScanner
{
    /**
     * Downloads an image from a remote URL and extracts text using Google Vision.
     *
     * @param string $imageUrl
     * @return string|null
     * @throws \Exception
     */
    public static function scanFromUrl(string $imageUrl): ?string
    {
        try {
            $http = new Client(['verify' => false]);
            $response = $http->get($imageUrl);
            $content = $response->getBody()->getContents();

            return self::scanImageContent($content);
        } catch (Exception $e) {
            throw new Exception("Failed to fetch image from URL: " . $e->getMessage());
        }
    }

    /**
     * Runs text detection on binary image content using Google Vision API.
     *
     * @param string $imageContent
     * @return string|null
     * @throws \Exception
     */
    public static function scanImageContent(string $imageContent): ?string
    {
        try {
            $client = new ImageAnnotatorClient([
                'credentials' => config('ocr.google_credentials'),
            ]);

            $image = (new Image)->setContent($imageContent);
            $feature = (new Feature)->setType(Feature\Type::TEXT_DETECTION);

            $request = (new AnnotateImageRequest)
                ->setImage($image)
                ->setFeatures([$feature]);

            $batchRequest = (new BatchAnnotateImagesRequest)
                ->setRequests([$request]);

            $batchResponse = $client->batchAnnotateImages($batchRequest);
            $response = $batchResponse->getResponses()[0] ?? null;
            $textAnnotations = $response?->getTextAnnotations() ?? [];

            return count($textAnnotations) > 0
                ? $textAnnotations[0]->getDescription()
                : null;

        } catch (Exception $e) {
            throw new Exception("OCR failed: " . $e->getMessage());
        }
    }
}


