# 📷 LMF Laravel OCR Package

A reusable, modular Laravel package that handles OCR scanning (via Google Cloud Vision) and parsing of invoices or receipts. Ideal for automating data extraction from uploaded image files.

---

## ✨ Features

- 🔍 OCR image scanning via Google Cloud Vision API
- 🧠 Invoice text parsing (invoice number, total, date, etc.)
- ⚙️ Publishable configuration file
- ✅ Works with remote URLs or base64 image content
- ♻️ Designed to be dropped into any Laravel project

---
## 📦 Main Installation


### 1. Add this to the require section of your composer.json:
```json
"lmf/package-ocr": "dev-main"
```
### 2. Add the Repository to composer.json
   In your Laravel project’s composer.json, add the package repository under the repositories section:

```json
"repositories": [
  {
    "type": "vcs",
    "url": "https://github.com/lmfventures/package-ocr.git"
  }
],
```
### 3. Set Composer Minimum Stability
This is located at the very bottom in your composer.json

    "minimum-stability": "dev",
    "prefer-stable": true
### 4. Authenticate Composer with Token
Run this once (Composer will save the credentials):
```bash
  composer config --auth github-oauth.github.com your_token_here
```
then change the stable to dev.
"minimum-stability": "dev",

Then require it:
```bash
  composer require lmf/package-ocr:dev-main
```
---
🔧 Required Configuration
1. Add credentials to config/services.php
```php
'google' => [
    'credentials' => base_path('path/to/your/service-account.json'),
]
```
2. Set environment variable in app/Providers/AppServiceProvider.php, inside the boot() method:
```php
public function boot(): void
{
    putenv('GOOGLE_APPLICATION_CREDENTIALS=' . config('services.google.credentials'));
}
```
---
To customize the package's config (currency, date format, credential key):
```bash
  php artisan vendor:publish --tag=ocr-config
```
This creates config/ocr.php:
```php
return [
    'google_credentials' => env('GOOGLE_APPLICATION_CREDENTIALS'),
    'default_currency' => 'php',
    'preferred_date_format' => 'd.m.Y',
]
```
Update these values or reference your .env file to suit your project.

---

🔁 Autoload Updates
Anytime you add or update classes, values, or config paths:
```bash
  composer dump-autoload
```

---



MIT © 2025 LMF Asbir Tech