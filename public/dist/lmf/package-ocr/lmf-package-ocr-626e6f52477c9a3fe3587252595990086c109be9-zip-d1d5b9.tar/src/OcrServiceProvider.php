<?php

namespace OcrTools;

use Illuminate\Support\ServiceProvider;

class OcrServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->mergeConfigFrom(__DIR__ . '/../config/ocr.php', 'ocr');
    }

    public function boot()
    {
        $this->publishes([
            __DIR__ . '/../config/ocr.php' => config_path('ocr.php'),
        ], 'ocr-config');
    }
}

