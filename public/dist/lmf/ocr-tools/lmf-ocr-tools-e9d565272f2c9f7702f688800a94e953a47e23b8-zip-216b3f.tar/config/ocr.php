<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Google Cloud Credentials
    |--------------------------------------------------------------------------
    |
    | This is the path to your service account JSON key. You can reference
    | this value in your config/services.php file to be used globally.
    |
    */

    'google_credentials' => env('GOOGLE_APPLICATION_CREDENTIALS'),

    /*
    |--------------------------------------------------------------------------
    | Default OCR Settings
    |--------------------------------------------------------------------------
    |
    | You can define defaults like the expected currency, language hints,
    | or preferred date format for parsing results.
    |
    */

    'default_currency' => 'php',
    'preferred_date_format' => 'd.m.Y',
];
