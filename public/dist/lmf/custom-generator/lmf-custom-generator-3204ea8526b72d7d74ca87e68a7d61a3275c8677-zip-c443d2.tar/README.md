# Custom Generator

Enhanced Artisan commands for generating models, migrations, requests, resources, repositories, and cache classes with advanced features.

## Features

- **Enhanced Model Generation**: Create models with automatic fillable arrays, casts, and relationships
- **Database Integration**: Generate models and migrations from existing database tables
- **Interactive Prompts**: User-friendly prompts using Laravel Prompts
- **Repository Pattern**: Generate repository classes and interfaces
- **Cache Classes**: Create model-based cache classes with TTL support
- **Form Requests**: Auto-generate validation rules based on database schema
- **JSON Resources**: Create API resources with automatic field mapping
- **Custom Stubs**: Enhanced stub files for better code generation

## Installation

### Via Composer (Private Repository)

```bash
# Add the repository to composer.json
composer config repositories.lmf-custom-generator git https://github.com/lmfventures/package-custom-generator.git

# Install the package
composer require lmf/custom-generator
```

### Alternative Installation Methods

#### Direct GitHub Installation
```bash
composer require lmfventures/package-custom-generator:dev-main
```

#### Local Development
```bash
# In your project's composer.json, add:
{
    "repositories": [
        {
            "type": "path",
            "url": "../package-custom-generator"
        }
    ]
}

# Then install
composer require lmf/custom-generator
```

#### Manual Installation
1. Clone this repository to your project
2. Add the service provider to your `config/app.php`:

```php
'providers' => [
    // ...
    Lmf\CustomGenerator\CustomGeneratorServiceProvider::class,
],
```

## Available Commands

### Model Commands

#### `make:custom-model`
Create enhanced models with interactive column definition and automatic generation of related files.

```bash
php artisan make:custom-model User
```

**Options:**
- `--all` - Generate all related files
- `--migration` - Create migration
- `--factory` - Create factory
- `--seed` - Create seeder
- `--controller` - Create controller
- `--requests` - Create form requests
- `--repository` - Create repository
- `--json-resource` - Create JSON resource
- `--cache` - Create cache class
- `--soft-deletes` - Add soft deletes
- `--no-timestamps` - Disable timestamps
- `--columns=JSON` - JSON string of column definitions

#### `make:custom-model-from-table`
Create models by reading existing database table structure.

```bash
php artisan make:custom-model-from-table User
```

### Migration Commands

#### `make:custom-migration`
Create enhanced migrations with column definitions.

```bash
php artisan make:custom-migration User
```

**Options:**
- `--columns=JSON` - JSON string of column definitions
- `--soft-deletes` - Add soft deletes
- `--no-timestamps` - Disable timestamps

### Request Commands

#### `make:custom-request`
Create form requests with auto-generated validation rules.

```bash
php artisan make:custom-request StoreUserRequest
```

**Options:**
- `--model=ModelName` - Model to read columns from
- `--columns=JSON` - JSON string of column definitions

### Resource Commands

#### `make:custom-resource`
Create JSON resources with automatic field mapping.

```bash
php artisan make:custom-resource UserResource
```

**Options:**
- `--model=ModelName` - Model to read columns from
- `--columns=JSON` - JSON string of column definitions
- `--soft-deletes` - Include soft deletes field
- `--no-timestamps` - Exclude timestamps

### Repository Commands

#### `make:repository`
Create repository classes and interfaces.

```bash
php artisan make:repository User
```

#### `make:repository-interface`
Create repository interfaces.

```bash
php artisan make:repository-interface UserRepositoryInterface User
```

### Cache Commands

#### `make:cache`
Create model-based cache classes.

```bash
php artisan make:cache User
```

**Options:**
- `--type=string` - Primary key type (default: int)

## Usage Examples

### Basic Model Generation

```bash
# Generate a User model with interactive prompts
php artisan make:custom-model User

# Generate with all related files
php artisan make:custom-model Product --all

# Generate with specific components
php artisan make:custom-model Order --migration --factory --repository
```

### Model from Database Table

```bash
# Create model from existing users table
php artisan make:custom-model-from-table User

# Create with all components
php artisan make:custom-model-from-table Product --all
```

### Custom Column Definitions

```bash
# Generate model with predefined columns
php artisan make:custom-model Product --columns='[
  {
    "column_name": "name",
    "data_type": "string",
    "nullable": false,
    "unique": false,
    "is_fillable": true,
    "default_value": ""
  },
  {
    "column_name": "price",
    "data_type": "decimal",
    "nullable": false,
    "unique": false,
    "is_fillable": true,
    "default_value": "0.00"
  }
]' --migration
```

### Repository Pattern

```bash
# Create repository with interface
php artisan make:repository User

# Create custom named repository
php artisan make:repository User CustomUserRepository
```

### Cache Classes

```bash
# Create cache class for User model
php artisan make:cache User

# Create cache with string primary key
php artisan make:cache Product Slug --type=string
```

## Configuration

The package automatically registers its service provider and makes all commands available without any additional configuration needed.

## Features in Detail

### Interactive Column Definition

When generating models, you can interactively define columns:

```
┌ Would you like to add custom columns? ────────────────────────────────────────┐
│ ● No / ○ Yes                                                                 │
└───────────────────────────────────────────────────────────────────────────────┘

┌ Column name ──────────────────────────────────────────────────────────────────┐
│ Enter column name or leave empty to finish                                   │
└───────────────────────────────────────────────────────────────────────────────┘

┌ Data type ────────────────────────────────────────────────────────────────────┐
│ ● string (VARCHAR)                                                           │
│   text (TEXT)                                                                │
│   integer (INT)                                                              │
│   bigInteger (BIGINT)                                                        │
│   boolean (TINYINT)                                                          │
│   date (DATE)                                                                │
│   datetime (DATETIME)                                                        │
│   timestamp (TIMESTAMP)                                                      │
│   decimal (DECIMAL)                                                          │
│   float (FLOAT)                                                              │
│   json (JSON)                                                                │
└───────────────────────────────────────────────────────────────────────────────┘
```

### Automatic Code Generation

The package automatically generates:

- **Fillable Arrays**: Based on column definitions
- **Casts Arrays**: Automatic type casting based on data types
- **Validation Rules**: Form request validation rules
- **Resource Fields**: JSON resource field mapping
- **Migration Schema**: Complete migration with column definitions

### Repository Pattern Implementation

The repository commands create:

- **BaseRepository**: Abstract base class with common methods
- **RepositoryInterface**: Base interface defining common methods
- **Model Repositories**: Specific repository implementations
- **Model Interfaces**: Specific repository interfaces

### Cache Pattern Implementation

The cache commands create:

- **CacheBase**: Abstract base class for caching
- **WithHelpers**: Trait with static helper methods
- **Model Cache Classes**: Specific cache implementations

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## License

This package is open-sourced software licensed under the [MIT license](LICENSE).

## Support

For support, please open an issue on GitHub or contact the maintainers. 