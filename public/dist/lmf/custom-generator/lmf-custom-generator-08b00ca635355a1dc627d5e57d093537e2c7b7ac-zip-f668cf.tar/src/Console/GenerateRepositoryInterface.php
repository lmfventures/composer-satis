<?php

namespace Lmf\CustomGenerator\Console;

use Illuminate\Console\GeneratorCommand;
use Illuminate\Support\Str;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputOption;

class GenerateRepositoryInterface extends GeneratorCommand
{
    use HasModel;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $name = 'make:repository-interface';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Create a new repository interface';

    /**
     * The type of class being generated.
     *
     * @var string
     */
    protected $type = 'RepositoryInterface';

    protected function getStub(): string
    {
        return $this->resolveStubPath('/../stubs/interface.stub');
    }

    protected function resolveStubPath($stub): string
    {
        // First check for custom stub in app directory
        $customPath = $this->laravel->basePath('app/CustomGenerator' . $stub);
        if (file_exists($customPath)) {
            return $customPath;
        }

        // Fallback to package stub
        $packageStubPath = __DIR__ . $stub;
        if (file_exists($packageStubPath)) {
            return $packageStubPath;
        }

        // Final fallback to Laravel base path
        return $this->laravel->basePath(trim($stub, '/'));
    }

    protected function getDefaultNamespace($rootNamespace): string
    {
        return $rootNamespace.'\Repositories\Contracts';
    }

    protected function buildClass($name): array|string
    {
        $replace = [
            '{{CLASS}}' => $this->getInterfaceName(),
        ];

        $replace = $this->buildModel($replace);

        return str_replace(
            array_keys($replace), array_values($replace), parent::buildClass($name)
        );
    }

    protected function getArguments(): array
    {
        return [
            ['name', InputArgument::REQUIRED, 'The name of the repository'],
            ['model', InputArgument::REQUIRED, 'The model name associated with the repository'],
        ];
    }

    protected function getOptions(): array
    {
        return [
            ['force', 'f', InputOption::VALUE_NONE, 'Create the class even if the interface already exists'],
        ];
    }

    protected function getNameInput(): string
    {
        $name = parent::getNameInput();

        if (Str::endsWith($name, 'RepositoryInterface')) {
            return $name;
        }

        return $name.'RepositoryInterface';
    }

    protected function getInterfaceName(): string
    {
        return $this->getNameInput();
    }
}
